# 🎤 Song Contest Bot

A Discord bot for running Eurovision-style song contest rankings. Users can score entries from each edition using the classic Eurovision points system (1–8, 10, 12), and see live leaderboards.

---

## Commands

| Command | Who | Description |
|---|---|---|
| `/edition create` | Admin | Create a new contest edition |
| `/edition list` | Anyone | List all editions |
| `/entry add` | Admin | Add a song entry to an edition |
| `/entry list` | Anyone | List all entries in an edition |
| `/entry remove` | Admin | Remove an entry |
| `/rank` | Anyone | Give a score to a song (1–8, 10, 12) |
| `/myranking` | Anyone | View your scores for an edition |
| `/scoreboard` | Anyone | View the leaderboard for an edition |

Admin commands require the **Manage Server** permission.

---

## Setup

### 1. Create a Discord Application

1. Go to https://discord.com/developers/applications
2. Click **New Application**, name it
3. Go to **Bot** → **Add Bot**
4. Under **Privileged Gateway Intents**, enable **Server Members Intent** if you want user display names
5. Copy your **Bot Token**
6. Go to **General Information** → copy your **Application ID**

### 2. Invite the Bot to Your Server

Use this URL (replace `YOUR_CLIENT_ID`):

```
https://discord.com/api/oauth2/authorize?client_id=YOUR_CLIENT_ID&permissions=2147485696&scope=bot%20applications.commands
```

### 3. Configure Environment

```bash
cp .env.example .env
```

Edit `.env`:
```
DISCORD_TOKEN=your_bot_token_here
CLIENT_ID=your_application_id_here
GUILD_ID=your_server_id_here   # optional, for instant command registration
```

To get your Guild ID: Right-click your server name in Discord → **Copy Server ID** (Developer Mode must be on in Settings → Advanced).

### 4. Install & Run

```bash
npm install

# Register slash commands (do this once, or after adding new commands)
node deploy-commands.js

# Start the bot
node index.js
```

---

## Data

All data is stored locally in `data/db.json`. Back this file up to preserve scores. No database server required.

---

## Example Workflow

```
/edition create  id:2024  name:Grand Prix 2024  year:2024
/entry add  edition:2024  country:France  artist:Zara Larsson  song:Golden Hour
/entry add  edition:2024  country:Sweden  artist:Loreen  song:Tattoo
/rank  edition:2024  entry_id:<autocomplete>  score:12
/scoreboard  edition:2024
```
